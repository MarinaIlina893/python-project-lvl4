# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['task_manager']

package_data = \
{'': ['*'], 'task_manager': ['templates/task_manager/*']}

install_requires = \
['Django==3.2.9',
 'asgiref==3.4.1',
 'dj-database-url==0.5.0',
 'django-bootstrap4>=21.1,<22.0',
 'gunicorn==20.1.0',
 'python-dotenv==0.19.2',
 'python_version>=0.0.2,<0.0.3',
 'pytz==2021.3',
 'sqlparse==0.4.2']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'MarinaIlina893',
    'author_email': 'marinailina893@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
